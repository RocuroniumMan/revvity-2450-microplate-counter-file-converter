# revvity-2450-microplate-counter-file-converter

Written for the revvity 2450 microplate counter data device, converts txt file output to xlsx. 

    Dependencies: 
    pip install pandas openpyxl xlwt
        #2.2.2
    pip install openpyxl
        #3.1.5
    pip install XlsxWriter
        #3.2.0